import logging
import json
import os
import requests

from flask import Flask
from flask import jsonify
from flask import request
from flask import send_file
from flask import redirect
from dotenv import load_dotenv

load_dotenv()

# Set up the app
app = Flask(__name__, static_folder='../client/dist/', static_url_path='/')
logger = logging.getLogger('ai-comprehension')

@app.before_request
def before_request():
    if not request.is_secure:
        url = request.url.replace('http://', 'https://', 1)
        code = 301
        return redirect(url, code=code)

class InvalidParam(Exception):
    status_code = 500

    def __init__(self, message, status_code=None, payload=None):
        Exception.__init__(self)
        self.message = message
        if status_code is not None:
            self.status_code = status_code
        self.payload = payload

    def to_dict(self):
        rv = dict(self.payload or ())
        rv['message'] = self.message
        return rv

@app.errorhandler(InvalidParam)
def handle_invalid_usage(error):
    response = jsonify(error.to_dict())
    response.status_code = error.status_code
    return response

def handle_invalid_param(name, value):
    logger.error(f'unrecognized {name}: {value}')
    raise InvalidParam(f'invalid value for {name}: {value}')

def handle_missing_param(name):
    logger.error(f'missing parameter {name}')
    raise InvalidParam(f'missing parameter {name}')

def get_input_file():
    # check if the post request has the file part
    if 'file' not in request.files:
        handle_missing_param('file')
    file = request.files['file']

    return file

def get_json_data():
    return request.json

@app.route('/claude', methods = ['POST'])
def ingest():
    temperature = request.args.get('temperature', default = 1, type = float)
    max_tokens = request.args.get('max_tokens', default = 1000, type = int)
    data = get_input_file().read().decode('utf-8').replace('\r', '')
    output = submit_prompt(data, max_tokens, temperature)

    return output

def submit_prompt(text:str, max_tokens:int, temperature:float):
    url = "https://api.anthropic.com/v1/complete"
    payload = json.dumps({
        'prompt': text,
        'model': 'claude-v1.3-100k',
        'max_tokens_to_sample': max_tokens,
        'temperature': temperature,
        'stop_sequences': [
            '\n\nHuman:'
        ]
    })
    api_key = os.environ['API_KEY']
    headers = {
        'x-api-key': api_key,
        'Content-Type': 'application/json'
    }
    response = requests.request("POST", url, headers=headers, data=payload)
    response_json = response.json()
    output = {}
    if 'completion' in response_json:
        output['success'] = True
        output['completion'] = response_json['completion']
    else:
        output['success'] = False
        output['error'] = response.text
    return output

# Set up the index route
@app.route('/')
def index():
    return app.send_static_file('index.html')

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host='0.0.0.0', port=port)
