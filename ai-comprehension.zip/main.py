

def main():
    print('but why bother')

if __name__ == "__main__":
    main()
