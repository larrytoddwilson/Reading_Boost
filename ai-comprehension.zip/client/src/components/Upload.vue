<template>
  <div class="container">
    <div class="large-12 medium-12 small-12 cell">
      <label>File
        <input type="file" id="file" ref="file" v-on:change="handleFileUpload()"/>
      </label>
      <label>Max Tokens:</label>
      <select v-model="maxTokens">
        <option v-for="option in tokenOptions" :key="option.value" v-bind:value="option.value">
          {{ option.text }}
        </option>
      </select>
      <label>Temperature:</label>
      <input v-model="temperature"/>
      <button :disabled="loading" v-on:click="submitClick()">Submit</button>
    </div>
    <div>
      {{ generatedText }}
    </div>
  </div>
</template>

<script>
  import axios from "axios";
  import { useToast } from "vue-toastification";
  export default {
    data(){
      return {
        file: '',
        tokenOptions: [
          {text: '1000', value: '1000'},
          {text: '8000', value: '8000'},
          {text: '33000', value: '33000'},
          {text: '50000', value: '50000'},
          {text: '75000', value: '75000'},
          {text: '100000', value: '100000'}
        ],
        maxTokens: '',
        temperature: 1,
        loading: false,
        generatedText: ''
      }
    },
    setup() {
      const toast = useToast();
      return { toast };
    },
    methods: {
      submitClick(){
        this.submitFile();
      },
      submitFile(){
        this.loading = true;
        let formData = new FormData();
        formData.append('file', this.file);
        const url = `/claude?max_tokens=${this.max_tokens}&temperature=${this.temperature}`;
        axios.post(
          url,
          formData,
          {
            headers: {
                'Content-Type': 'multipart/form-data'
            }
          },
          {responseType: 'json'}
        ).then((response)=>{
          this.generatedText = response.data.completion; 
          this.loading = false;
        })
        .catch(function(err){
          console.log('FAILURE!!');
          console.log(err);
          this.loading = false;
        });
      },
      handleFileUpload(){
        this.file = this.$refs.file.files[0];
      }
    }
  }
</script>
